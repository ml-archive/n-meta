import XCTest
@testable import NMetaTests

XCTMain([
    testCase(NMetaTests.allTests),
])
